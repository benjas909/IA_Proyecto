# IA_Proyecto

Para ejecutar el código, se debe ejecutar el comando "make" en terminal, y luego el comando "./bin/main <filename> <d1> <d2>", reemplazando los brackets con los parámetros deseados.
Para limpiar los archivos generados en la compilación, se debe ejecutar "make clean".
