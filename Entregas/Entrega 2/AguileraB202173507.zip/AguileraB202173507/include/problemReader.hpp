#ifndef PROBLEMREADER_HPP
#define PROBLEMREADER_HPP
#include <string>
#include <fstream>
#include <stdio.h>
#include <sstream>
#include "./TUP.hpp"

TUP readProblemFile(string fileName);


#endif
