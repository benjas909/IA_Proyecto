#ifndef CONSTRAINTS_HPP
#define CONSTRAINTS_HPP

// int 


#endif