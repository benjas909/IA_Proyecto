# IA_Proyecto

Para ejecutar el código, se debe ejecutar el comando "make run" en terminal.
Para limpiar los archivos generados en la compilación, se debe ejecutar "make clean".
